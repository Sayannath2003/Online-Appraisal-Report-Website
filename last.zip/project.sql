-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2023 at 05:41 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `apprisal`
--

CREATE TABLE `apprisal` (
  `Emp_ID` varchar(10) DEFAULT NULL,
  `Emp_Name` varchar(20) DEFAULT NULL,
  `Emp_Dept` varchar(20) DEFAULT NULL,
  `appraisalDate_Emp` date DEFAULT NULL,
  `Start` varchar(50) DEFAULT NULL,
  `End` varchar(50) DEFAULT NULL,
  `Brief_Description_Duties_Emp` varchar(100) DEFAULT NULL,
  `Target1` varchar(100) DEFAULT NULL,
  `Achievement1` varchar(200) DEFAULT NULL,
  `Target2` varchar(200) DEFAULT NULL,
  `Achievement2` varchar(200) DEFAULT NULL,
  `Target3` varchar(200) DEFAULT NULL,
  `Achievement3` varchar(200) DEFAULT NULL,
  `Target4` varchar(200) DEFAULT NULL,
  `Achievement4` varchar(200) DEFAULT NULL,
  `Brief_Achievements_Emp` varchar(200) DEFAULT NULL,
  `Brief_Shortfalls_Emp` varchar(200) DEFAULT NULL,
  `Annual_Return_On_Immovable_Property_Emp` varchar(200) DEFAULT NULL,
  `overallComments_Emp` varchar(200) DEFAULT NULL,
  `Manager_ID` varchar(10) DEFAULT NULL,
  `Manager_Name` varchar(20) DEFAULT NULL,
  `appraisalDate_Manager` date DEFAULT NULL,
  `Indicate_Areas_Of_Strength_And_Lesser_Strength` varchar(200) DEFAULT NULL,
  `Attitude` varchar(200) DEFAULT NULL,
  `Relation_With_Outside` varchar(200) DEFAULT NULL,
  `Recommendations_For_Training` varchar(200) DEFAULT NULL,
  `State_Of_Health` varchar(200) DEFAULT NULL,
  `Integrity` varchar(200) DEFAULT NULL,
  `Attitude_Point_M` decimal(5,2) DEFAULT NULL,
  `Sense_Of_Responsibility_Point_M` decimal(5,2) DEFAULT NULL,
  `Maintenance_Of_Discipline_Point_M` decimal(5,2) DEFAULT NULL,
  `Communication_Skills_Point_M` decimal(5,2) DEFAULT NULL,
  `Leadership_Quality_Point_M` decimal(5,2) DEFAULT NULL,
  `Capacity_To_Work_In_Teamspirit_Point_M` decimal(5,2) DEFAULT NULL,
  `Capacity_To_Work_In_Timelimit_Point_M` decimal(5,2) DEFAULT NULL,
  `Inter_Personal_Relations_Point_M` decimal(5,2) DEFAULT NULL,
  `Overall_Grading_Personal_Attributes_M` decimal(5,3) DEFAULT NULL,
  `Knowledge_Of_Rules_Point_M` decimal(5,2) DEFAULT NULL,
  `Strategic_Planning_Ability_Point_M` decimal(5,2) DEFAULT NULL,
  `Decision_Making_Ability_Point_M` decimal(5,2) DEFAULT NULL,
  `Coordination_Ability_Point_M` decimal(5,2) DEFAULT NULL,
  `Ability_To_Motivate_And_Develop_Point_M` decimal(5,2) DEFAULT NULL,
  `Overall_Grading_Functional_Competency_M` decimal(5,3) DEFAULT NULL,
  `Pen_Picture_About_Officer_M` varchar(200) DEFAULT NULL,
  `Overall_M` decimal(5,3) DEFAULT NULL,
  `Teamlead_ID` varchar(20) DEFAULT NULL,
  `Teamlead_Name` varchar(200) DEFAULT NULL,
  `appraisalDate_Teamlead` date DEFAULT NULL,
  `Attitude_Point_L` decimal(5,2) DEFAULT NULL,
  `Sense_Of_Responsibility_Point_L` decimal(5,2) DEFAULT NULL,
  `Maintenance_Of_Discipline_Point_L` decimal(5,2) DEFAULT NULL,
  `Communication_Skills_Point_L` decimal(5,2) DEFAULT NULL,
  `Leadership_Quality_Point_L` decimal(5,2) DEFAULT NULL,
  `Capacity_To_Work_In_Teamspirit_Point_L` decimal(5,2) DEFAULT NULL,
  `Capacity_To_Work_In_Timelimit_Point_L` decimal(5,2) DEFAULT NULL,
  `Inter_Personal_Relations_Point_L` decimal(5,2) DEFAULT NULL,
  `Overall_Grading_Personal_Attributes_L` decimal(5,3) DEFAULT NULL,
  `Knowledge_Of_Rules_Point_L` decimal(5,2) DEFAULT NULL,
  `Strategic_Planning_Ability_Point_L` decimal(5,2) DEFAULT NULL,
  `Decision_Making_Ability_Point_L` decimal(5,2) DEFAULT NULL,
  `Coordination_Ability_Point_L` decimal(5,2) DEFAULT NULL,
  `Ability_To_Motivate_And_Develop_Point_L` decimal(5,2) DEFAULT NULL,
  `Overall_Grading_Functional_Competency_L` decimal(5,3) DEFAULT NULL,
  `Overall_L` decimal(5,3) DEFAULT NULL,
  `Status` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `apprisal`
--

INSERT INTO `apprisal` (`Emp_ID`, `Emp_Name`, `Emp_Dept`, `appraisalDate_Emp`, `Start`, `End`, `Brief_Description_Duties_Emp`, `Target1`, `Achievement1`, `Target2`, `Achievement2`, `Target3`, `Achievement3`, `Target4`, `Achievement4`, `Brief_Achievements_Emp`, `Brief_Shortfalls_Emp`, `Annual_Return_On_Immovable_Property_Emp`, `overallComments_Emp`, `Manager_ID`, `Manager_Name`, `appraisalDate_Manager`, `Indicate_Areas_Of_Strength_And_Lesser_Strength`, `Attitude`, `Relation_With_Outside`, `Recommendations_For_Training`, `State_Of_Health`, `Integrity`, `Attitude_Point_M`, `Sense_Of_Responsibility_Point_M`, `Maintenance_Of_Discipline_Point_M`, `Communication_Skills_Point_M`, `Leadership_Quality_Point_M`, `Capacity_To_Work_In_Teamspirit_Point_M`, `Capacity_To_Work_In_Timelimit_Point_M`, `Inter_Personal_Relations_Point_M`, `Overall_Grading_Personal_Attributes_M`, `Knowledge_Of_Rules_Point_M`, `Strategic_Planning_Ability_Point_M`, `Decision_Making_Ability_Point_M`, `Coordination_Ability_Point_M`, `Ability_To_Motivate_And_Develop_Point_M`, `Overall_Grading_Functional_Competency_M`, `Pen_Picture_About_Officer_M`, `Overall_M`, `Teamlead_ID`, `Teamlead_Name`, `appraisalDate_Teamlead`, `Attitude_Point_L`, `Sense_Of_Responsibility_Point_L`, `Maintenance_Of_Discipline_Point_L`, `Communication_Skills_Point_L`, `Leadership_Quality_Point_L`, `Capacity_To_Work_In_Teamspirit_Point_L`, `Capacity_To_Work_In_Timelimit_Point_L`, `Inter_Personal_Relations_Point_L`, `Overall_Grading_Personal_Attributes_L`, `Knowledge_Of_Rules_Point_L`, `Strategic_Planning_Ability_Point_L`, `Decision_Making_Ability_Point_L`, `Coordination_Ability_Point_L`, `Ability_To_Motivate_And_Develop_Point_L`, `Overall_Grading_Functional_Competency_L`, `Overall_L`, `Status`) VALUES
('E_0001', 'Ratan Pal', 'Finance', '2023-10-04', NULL, NULL, 'Excellent(5)', 'sa', 'Good(4)', 'dassefsda', 'Average(3)', 'fsdafwefrweqw', 'ADASDSAD', 'asdawdasdasdsadSADASDAS', 'AAAAAAAAAAAAAA', '', NULL, NULL, 'BBBBBBBBBBBB', 'M_0005', 'Surya Kanta Jana', '2023-10-12', 'adssdafsdfsd', 'fdsassafdds', 'sdfasdfsdfa', 'sdfasfdfdsa', 'asdffasdsdfa', 'sdfasdfaasdf', 8.00, 9.30, 4.60, 6.70, 4.60, 1.60, 9.50, 7.90, 7.800, 7.60, 9.80, 5.50, 7.00, 4.90, 6.300, 'sdasdas', 4.300, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4),
('E_0007', 'Aritra Sengupta', 'Finance', '2023-10-13', 'January-2023', 'March-2023', 'Developing of Website', 'Medical Dept forms', 'Successfully Achieved', 'BAS device up-gradation when required', 'Successfully Achieved', 'online temporary Duty MRO & Cheque Slip module', 'Successfully Developed', 'Database maintennce', 'Maintained Daily', 'All PHP modules and Google forms have been successfully developed within time framed', 'Online Temporary Duty module for MRO & Cheque Slip successfully developed but due to shortage of testing the module is yet to be implemented', 'Yessssssss', 'Nice experience', 'M_0005', 'Surya Kanta Jana', '2023-10-13', 'asdsad', 'asdasd', 'asdasd', 'adsasd', 'asdasd', 'asdasd', 4.00, 0.90, 0.40, 1.00, 3.70, 4.00, 4.00, 4.00, 2.750, 4.00, 4.00, 4.00, 4.00, 4.30, 4.060, 'fddfskkk', 3.405, 'L_0002', 'Avinash Kumar Mittal', '2023-10-13', 7.00, 5.50, 4.60, 4.60, 1.80, 2.00, 3.60, 5.50, 4.325, 5.80, 4.30, 4.40, 4.00, 4.00, 4.500, 4.413, 4),
('E_0002', 'Debdwaipayan Biswas', 'Outreach', '2023-10-13', 'January-2023', 'October-2023', 'sadas', 'saddasasddsa', 'sdaasd', 'asdasd', 'asdasd', 'asdasdsda', 'asddasasd', 'sdaasd', 'daasdasd', 'asdsad', 'asdasd', 'asdasd', 'asdd', 'M_0004', 'Surajit Das', '2023-10-13', 'das', 'dasasd', 'sdfa', 'sdfa', 'fsda', 'dfsasd', 2.00, 0.40, 1.00, 1.40, 2.00, 2.20, 1.50, 1.60, 1.513, 1.60, 2.30, 2.80, 3.60, 2.40, 2.540, 'sdfsfd', 2.026, 'L_0002', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4),
('E_0004', 'Ram Mondal', 'Marketing', '2023-10-15', 'dssa', 'bhghjg', 'ghghg', 'ghgghj', 'gjgjgg', 'jgggjjgg', 'jgjg', 'jg', 'jggjggj', 'jgjg', 'gjg', 'jgj', 'g', 'gj', 'jgjg', 'M_0002', 'Raju Nath', '2023-10-15', 'bbbbj', 'jhjh', 'jjgjg', 'jgjh', 'ghjgh', 'ghjghg', 3.00, 2.90, 3.00, 3.00, 3.00, 3.00, 3.00, 3.00, 2.988, 3.00, 3.00, 3.00, 3.00, 3.00, 3.000, 'dsvdsf', 2.994, 'L_0001', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3),
('E_0006', 'Anubrata Roy', 'Marketing', '2023-10-15', 'hjhj', 'hjhj', 'jhj', 'hjhhhhjjh', 'jhhjhj', 'jhjhjhjhjhjh', 'hjhjhhj', 'hjhhjhj', 'jhjhjhjh', 'hjjh', 'jhjhhjjh', 'jhjhjhjhjh', 'jjhjhjhhj', 'jhjhjhjh', 'jhjhjhj', 'M_0002', 'Raju Nath', '2023-10-15', 'dsfsa', 'ggjhgjh', 'ghghgh', 'ggjhjgj', 'gjg', 'ggjgj', 9.00, 9.00, 9.00, 9.00, 9.00, 9.00, 9.00, 9.00, 9.000, 9.00, 9.00, 9.00, 9.00, 9.00, 9.000, 'vvbhjgjhgjmg', 9.000, 'L_0001', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3),
('E_0003', 'Sayan Nath', 'Outreach', '2023-10-15', 'September-2023', 'October-2023', 'Developing of Website based Softwares', 'Medical Dept forms', 'Successfully achieved', 'BAS device up-gradation when required', 'Successfully achieved', 'online temporary Duty MRO & Cheque Slip module', 'Successfully developed', 'Database maintennce', 'Maintained Daily', 'All PHP modules and Google forms have been successfully developed within time framed', 'Online Temporary Duty module for MRO & Cheque Slip successfully developed but due to shortage of testing the module is yet to be implemented', 'Yes', 'Good', 'M_0004', 'Surajit Das', '2023-10-15', 'Employee is sincere, intelligent and hard working', 'Positive and Cooperative', 'The officer is sensitive and responsive', 'Web based programming language like PHP, Java Script', 'Fit and healthy', 'Beyond doubt', 9.10, 9.00, 9.00, 9.00, 9.00, 7.00, 9.00, 9.00, 8.763, 9.00, 9.00, 9.00, 7.50, 8.50, 8.600, 'Employee is sincere, intelligent and hard working', 8.681, 'L_0002', 'Avinash Kumar Mittal', '2023-10-16', 9.00, 9.00, 9.00, 9.00, 7.50, 9.00, 9.00, 8.50, 8.750, 8.50, 7.50, 9.00, 9.00, 8.50, 8.500, 8.625, 6);

-- --------------------------------------------------------

--
-- Table structure for table `choose`
--

CREATE TABLE `choose` (
  `Department` varchar(20) DEFAULT NULL,
  `Manager_ID` varchar(20) DEFAULT NULL,
  `Teamlead_ID` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `choose`
--

INSERT INTO `choose` (`Department`, `Manager_ID`, `Teamlead_ID`) VALUES
('Technical', 'M_0001', 'L_0001'),
('Marketing', 'M_0002', 'L_0001'),
('Design', 'M_0003', 'L_0001'),
('Outreach', 'M_0004', 'L_0002'),
('Finance', 'M_0005', 'L_0002');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `Emp_ID` varchar(10) DEFAULT NULL,
  `Password` varchar(20) DEFAULT NULL,
  `Emp_Name` varchar(20) DEFAULT NULL,
  `Emp_Dept` varchar(20) DEFAULT NULL,
  `Emp_Age` int(11) DEFAULT NULL,
  `Emp_Address` varchar(50) DEFAULT NULL,
  `Emp_Phone_No` bigint(11) DEFAULT NULL,
  `Emp_Joining_Date` date DEFAULT NULL,
  `Emp_Email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`Emp_ID`, `Password`, `Emp_Name`, `Emp_Dept`, `Emp_Age`, `Emp_Address`, `Emp_Phone_No`, `Emp_Joining_Date`, `Emp_Email`) VALUES
('E_0001', '12345678', 'Ratan Pal', 'Finance', 25, 'Belghoria', 8456798991, '2021-11-30', 'ratanpal@gmail.com'),
('E_0005', '1234546878', 'Raj Das', 'Design', 31, 'Bardwan', 8896356897, '2021-04-01', 'rajdas@gmail.com'),
('E_0003', '12345678', 'Sayan Nath', 'Outreach', 19, 'Hindmotor', 8420725589, '2023-09-04', 'sayannath2003sn@gmail.com'),
('E_0004', '12345678', 'Ram Mondal', 'Marketing', 34, 'Howrah', 9756823456, '2011-01-12', 'rammondal@gmail.com'),
('E_0007', '11111111', 'Aritra Sengupta', 'Finance', 21, 'Saltlake', 6290078652, '2019-12-18', 'aritra@gmail.com'),
('E_0002', 'bolbonaa', 'Debdwaipayan Biswas', 'Outreach', 38, 'Dumdum', 8961613697, '2013-11-15', 'debbiswas@gmail.com'),
('E_0006', '66666666', 'Anubrata Roy', 'Marketing', 20, 'Uttarpara', 6290018925, '2022-12-17', 'anubrata@gmail.com'),
('E_0009', 'bolbonaa', 'Araj Saha', 'Design', 14, 'Africa', 7898565221, '2021-02-01', 'sasa@gmail.com'),
('E_0010', 'bolbonaa', 'AS sda', 'Marketing', 45, 'Delhi', 9987858632, '2019-04-02', 'sasa@gmail.com'),
('E_0011', 'bolbonaa', 'ABC', 'Technical', 45, 'ihsidvns', 1111111111, '2022-12-05', 'sndf@gmail.com'),
('E_0012', 'bolbonaa', 'Anwita Bera', 'Outreach', 24, 'Serampur', 6265897515, '2014-10-17', 'anwita@gmail.com'),
('E_0013', '11111111', 'Moumita Nath', 'Marketing', 46, 'Sodepur', 8336835118, '2021-01-12', 'moumita@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `Manager_ID` varchar(10) DEFAULT NULL,
  `Password` varchar(20) DEFAULT NULL,
  `Manager_Name` varchar(20) DEFAULT NULL,
  `Manager_Age` int(11) DEFAULT NULL,
  `Manager_Address` varchar(50) DEFAULT NULL,
  `Manager_Phone_No` bigint(11) DEFAULT NULL,
  `Manager_Joining_Date` date DEFAULT NULL,
  `Manager_Email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`Manager_ID`, `Password`, `Manager_Name`, `Manager_Age`, `Manager_Address`, `Manager_Phone_No`, `Manager_Joining_Date`, `Manager_Email`) VALUES
('M_0001', '11111111', 'Sanjit Nath', 49, 'Delhi', 9748177176, '2011-12-29', 'sanjitnath1973@gmail.com'),
('M_0002', '22222222', 'Raju Nath', 50, 'Kanpur', 9896165897, '2017-01-12', 'rajunath@gmail.com'),
('M_0003', '33333333', 'Anubhab Chakraborty', 34, 'Konnagar', 9745832545, '2014-12-01', 'Anubhab@gmail.com'),
('M_0004', '44444444', 'Surajit Das', 37, 'Newtown', 6254732145, '2019-05-03', 'Surajit@gmail.com'),
('M_0005', '55555555', 'Surya Kanta Jana', 46, 'Bardwan', 9989774569, '2013-01-06', 'Surya@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `teamlead`
--

CREATE TABLE `teamlead` (
  `Teamlead_ID` varchar(10) DEFAULT NULL,
  `Password` varchar(20) DEFAULT NULL,
  `Teamlead_Name` varchar(20) DEFAULT NULL,
  `Teamlead_Age` int(11) DEFAULT NULL,
  `Teamlead_Address` varchar(50) DEFAULT NULL,
  `Teamlead_Phone_No` bigint(11) DEFAULT NULL,
  `Teamlead_Joining_Date` date DEFAULT NULL,
  `Teamlead_Email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `teamlead`
--

INSERT INTO `teamlead` (`Teamlead_ID`, `Password`, `Teamlead_Name`, `Teamlead_Age`, `Teamlead_Address`, `Teamlead_Phone_No`, `Teamlead_Joining_Date`, `Teamlead_Email`) VALUES
('L_0001', '12345678', 'Tapas Kundu', 57, 'Hyderabad', 9863245785, '2001-01-03', 'Tapas@gmail.com'),
('L_0002', '22222222', 'Avinash Kumar Mittal', 53, 'Jharkhand', 9862512457, '2001-07-04', 'Avinash@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
